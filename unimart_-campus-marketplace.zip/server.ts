import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

// Ensure Gemini API key is available
const apiKey = process.env.GEMINI_API_KEY;
const ai = apiKey ? new GoogleGenAI({ apiKey }) : null;

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Increase payload limit for base64 images
  app.use(express.json({ limit: '50mb' }));

  app.post('/api/analyze-item', async (req, res) => {
    if (!ai) {
      return res.status(500).json({ error: 'GEMINI_API_KEY is not configured.' });
    }

    try {
      const { imageParams } = req.body;
      
      if (!imageParams || !imageParams.base64 || !imageParams.mimeType) {
        return res.status(400).json({ error: 'Missing image data.' });
      }

      // @ts-ignore
      const { ThinkingLevel } = await import('@google/genai').catch(() => ({ ThinkingLevel: { HIGH: 'HIGH' } }));

      const response = await ai.models.generateContent({
        model: 'gemini-3.1-pro-preview',
        contents: [
          {
            text: 'Analyze this image and identify the item being sold. Return a JSON object with: title (short descriptive name), category (one of: Textbooks, Notes & Study Material, Electronics & Gadgets, Lab Coats & Equipment, Stationery & Supplies, Other), priceEstimate (suggested reasonable price for a campus marketplace, in USD, as a string like "$15 - $25"), and description (a 2-sentence engaging description for a buyer).',
          },
          {
            inlineData: {
              data: imageParams.base64,
              mimeType: imageParams.mimeType,
            },
          },
        ],
        config: {
          responseMimeType: 'application/json',
          thinkingConfig: {
            thinkingLevel: 'HIGH',
          },
          responseSchema: {
            // @ts-ignore
            type: 'OBJECT',
            properties: {
              title: { type: 'STRING' },
              category: { type: 'STRING' },
              priceEstimate: { type: 'STRING' },
              description: { type: 'STRING' },
            },
            required: ['title', 'category', 'priceEstimate', 'description'],
          },
        },
      });

      try {
        const textResponse = response.text || '';
        const parsed = JSON.parse(textResponse);
        res.json(parsed);
      } catch (parseError) {
        console.error('Failed to parse Gemini response:', parseError);
        res.status(500).json({ error: 'Invalid response from AI.' });
      }
    } catch (error: any) {
      console.error('Error analyzing item:', error);
      res.status(500).json({ error: error.message || 'Error communicating with AI service.' });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
