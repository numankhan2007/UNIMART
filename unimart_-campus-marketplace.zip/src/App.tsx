import React, { useState } from 'react';
import { 
  Search, Bell, ChevronDown, GraduationCap, ArrowRight,
  PlusSquare, ShieldCheck, Lock, Building2, Users,
  LayoutGrid, Zap, Verified, BookOpen, FileText,
  Smartphone, FlaskConical, PenTool, ChevronRight,
  SlidersHorizontal, ShoppingBag, Send, Mail, Heart
} from 'lucide-react';
import WebGLBackground from './components/WebGLBackground';
import AIAssistantModal from './components/AIAssistantModal';

const HBeam = ({ y, x, width, reverse, delay, duration }: any) => (
  <div className="absolute h-[2px] overflow-hidden rounded-full" style={{ top: `calc(50% + ${y}px)`, left: `calc(50% + ${x}px)`, width: `${width}px` }}>
    <div className="w-[40%] h-full rounded-full" style={{
      background: reverse ? 'linear-gradient(to left, transparent, rgba(99, 102, 241, 0.9) 100%)' : 'linear-gradient(to right, transparent, rgba(99, 102, 241, 0.9) 100%)',
      animation: `${reverse ? 'beam-left' : 'beam-right'} ${duration}s linear infinite`,
      animationDelay: `${delay}s`,
      transform: reverse ? 'translateX(250%)' : 'translateX(-100%)',
      boxShadow: '0 0 10px 1px rgba(99, 102, 241, 0.4)'
    }} />
  </div>
);

const VBeam = ({ x, y, height, reverse, delay, duration }: any) => (
  <div className="absolute w-[2px] overflow-hidden rounded-full" style={{ top: `calc(50% + ${y}px)`, left: `calc(50% + ${x}px)`, height: `${height}px` }}>
    <div className="h-[40%] w-full rounded-full" style={{
      background: reverse ? 'linear-gradient(to top, transparent, rgba(99, 102, 241, 0.9) 100%)' : 'linear-gradient(to bottom, transparent, rgba(99, 102, 241, 0.9) 100%)',
      animation: `${reverse ? 'beam-up' : 'beam-down'} ${duration}s linear infinite`,
      animationDelay: `${delay}s`,
      transform: reverse ? 'translateY(250%)' : 'translateY(-100%)',
      boxShadow: '0 0 10px 1px rgba(99, 102, 241, 0.4)'
    }} />
  </div>
);

export default function App() {
  const [isAIModalOpen, setIsAIModalOpen] = useState(false);
  const [isMobileSearchOpen, setIsMobileSearchOpen] = useState(false);

  return (
    <div className="font-body-base text-body-base min-h-screen flex flex-col pt-24 relative overflow-hidden">
      <style>{`
        @keyframes beam-right { 0% { transform: translateX(-100%); } 100% { transform: translateX(250%); } }
        @keyframes beam-left { 0% { transform: translateX(250%); } 100% { transform: translateX(-100%); } }
        @keyframes beam-down { 0% { transform: translateY(-100%); } 100% { transform: translateY(250%); } }
        @keyframes beam-up { 0% { transform: translateY(250%); } 100% { transform: translateY(-100%); } }
      `}</style>
      <WebGLBackground />
      <AIAssistantModal isOpen={isAIModalOpen} onClose={() => setIsAIModalOpen(false)} />

      {/* TopNavBar */}
      <nav className={`fixed top-2 md:top-4 left-1/2 -translate-x-1/2 w-[95%] max-w-7xl rounded-full backdrop-blur-[24px] px-3 md:px-6 py-1.5 md:py-2 z-50 bg-glass-bg border border-border-standard shadow-md flex justify-between items-center h-[44px] md:h-auto gap-2 md:gap-8 transition-all duration-300 ${isMobileSearchOpen ? 'overflow-hidden' : ''}`}>
        {isMobileSearchOpen ? (
          <div className="flex w-full items-center gap-2 animate-fade-in-up" style={{ animationDuration: '0.2s' }}>
            <button onClick={() => setIsMobileSearchOpen(false)} className="p-1 text-text-secondary shrink-0">
               <ChevronRight className="w-5 h-5" style={{ transform: 'rotate(180deg)' }} />
            </button>
            <div className="flex-1 relative">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 text-outline w-3.5 h-3.5" />
              <input 
                autoFocus
                className="w-full pl-8 pr-3 py-1.5 rounded-full bg-surface-white border border-border-standard focus:outline-none focus:border-primary-container text-xs shadow-inner" 
                placeholder="Search products, notes..." 
                type="text"
              />
            </div>
          </div>
        ) : (
          <>
            <div className="flex items-center gap-2 md:gap-4 shrink-0 transition-all">
              <div className="w-6 h-6 md:w-8 md:h-8 bg-primary-container rounded flex items-center justify-center text-white font-bold text-xs md:text-base">U</div>
              <span className="font-display-hero-mobile text-sm md:text-2xl font-bold tracking-tight text-text-primary">UNIMART</span>
            </div>
            
            <div className="hidden md:flex flex-1 max-w-md relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-outline w-5 h-5" />
              <input 
                className="w-full pl-10 pr-4 py-2 rounded-full bg-surface-white border border-border-standard focus:outline-none focus:border-primary-container focus:ring-2 focus:ring-primary-container/20 text-sm shadow-inner" 
                placeholder="Search products, notes, books..." 
                type="text"
              />
            </div>

            <div className="hidden md:flex items-center gap-6 font-headline-card text-headline-card text-[15px]">
              <a className="text-primary font-bold border-b-2 border-primary pb-1" href="#">Browse</a>
              <a className="text-text-secondary hover:text-primary transition-colors hover:bg-surface-container rounded-full px-3 py-1" href="#">Sell</a>
              <a className="text-text-secondary hover:text-primary transition-colors hover:bg-surface-container rounded-full px-3 py-1" href="#">Orders</a>
            </div>

            <div className="flex items-center gap-3 md:gap-4 shrink-0 transition-all">
              <button 
                className="md:hidden p-1 text-text-secondary hover:text-primary transition-colors"
                onClick={() => setIsMobileSearchOpen(true)}
              >
                <Search className="w-4 h-4 md:w-5 md:h-5" />
              </button>
              <button className="text-text-secondary hover:text-primary transition-colors relative p-1 md:p-0">
                <Bell className="w-4 h-4 md:w-5 md:h-5" />
                <span className="absolute top-0 right-0 md:-top-1 md:-right-1 w-3 h-3 md:w-4 md:h-4 bg-primary-container text-white text-[8px] md:text-[10px] rounded-full flex items-center justify-center">2</span>
              </button>
              <div className="flex items-center gap-2 cursor-pointer">
                <img 
                  alt="User profile" 
                  className="w-6 h-6 md:w-8 md:h-8 rounded-full border border-border-standard object-cover" 
                  src="https://images.unsplash.com/photo-1599566150163-29194dcaad36?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80"
                />
                <span className="text-sm font-medium hidden md:block">Numankhan@2007</span>
                <ChevronDown className="w-4 h-4 text-text-secondary hidden md:block" />
              </div>
            </div>
          </>
        )}
      </nav>

      {/* Hero Section */}
      <header className="relative w-full max-w-7xl mx-auto px-4 md:px-8 pt-24 pb-28 flex flex-col items-center justify-center text-center overflow-visible">
        {/* Visual Backdrop: Soft gradient glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-primary-container/10 blur-[100px] rounded-full pointer-events-none -z-10"></div>
        {/* Academic subtle geometric pattern overlay */}
        <div 
          className="absolute inset-0 -z-10 opacity-70 pointer-events-none" 
          style={{
            backgroundImage: 'radial-gradient(circle at center, #4f46e5 1.5px, transparent 1.5px)',
            backgroundSize: '32px 32px',
            backgroundPosition: 'center center',
            maskImage: 'radial-gradient(ellipse at center, black 40%, transparent 70%)',
            WebkitMaskImage: 'radial-gradient(ellipse at center, black 40%, transparent 70%)'
          }}
        ></div>
        
        {/* Animated grid beams */}
        <div className="absolute inset-0 -z-10 pointer-events-none opacity-80" style={{ maskImage: 'radial-gradient(ellipse at center, black 40%, transparent 70%)', WebkitMaskImage: 'radial-gradient(ellipse at center, black 40%, transparent 70%)' }}>
          <HBeam y={-128} x={-384} width={256} reverse={false} duration={3} delay={0} />
          <HBeam y={-64} x={0} width={320} reverse={true} duration={4} delay={1.5} />
          <HBeam y={32} x={-256} width={224} reverse={false} duration={2.5} delay={0.5} />
          <HBeam y={96} x={64} width={256} reverse={true} duration={3.5} delay={2} />
          <HBeam y={160} x={-128} width={384} reverse={false} duration={4.5} delay={1} />
          <HBeam y={-192} x={-192} width={256} reverse={true} duration={3} delay={2.5} />
          <HBeam y={128} x={-320} width={192} reverse={true} duration={2.5} delay={0.2} />

          <VBeam x={-160} y={-256} height={256} reverse={false} duration={3.5} delay={1} />
          <VBeam x={-32} y={-128} height={320} reverse={true} duration={4} delay={0} />
          <VBeam x={96} y={-320} height={192} reverse={false} duration={2.5} delay={2} />
          <VBeam x={224} y={-64} height={256} reverse={true} duration={3} delay={0.5} />
          <VBeam x={-288} y={-192} height={384} reverse={false} duration={4.5} delay={1.5} />
          <VBeam x={160} y={32} height={256} reverse={false} duration={2.8} delay={1.2} />
        </div>
        
        <div className="space-y-4 md:space-y-8 flex flex-col items-center max-w-3xl z-10 px-2 lg:px-0 mt-8 md:mt-0">
          <h1 className="text-[#6366f1] font-display-hero text-[3.5rem] leading-[1] sm:text-6xl md:text-8xl lg:text-[100px] tracking-tighter font-extrabold mb-1 md:mb-4 uppercase drop-shadow-sm">
            UNIMART
          </h1>
          
          <h2 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-bold text-text-secondary animate-fade-in-up delay-100 max-w-2xl leading-[1.2] px-2 text-center">
            Buy & Sell with <br className="hidden sm:block" /> <span className="text-primary-container">Campus</span> Students
          </h2>
          
          <p className="text-sm sm:text-base md:font-body-large md:text-body-large text-text-secondary w-full max-w-[300px] sm:max-w-md lg:max-w-lg mx-auto animate-fade-in-up delay-200 px-4">
            The premium marketplace designed exclusively for university students. <br className="hidden md:block" />Trade textbooks, electronics, and essentials — safely and privately.
          </p>
          
          <div className="flex flex-col sm:flex-row flex-wrap justify-center gap-3 md:gap-4 pt-2 md:pt-4 animate-fade-in-up delay-300 w-full sm:w-auto px-6 sm:px-0">
            <button className="w-full sm:w-auto bg-primary-container text-white px-4 py-2.5 sm:px-6 sm:py-3 rounded-xl font-button-text text-sm sm:text-base flex justify-center items-center gap-2 hover:bg-primary transition-all hover:-translate-y-0.5 shadow-md hover:shadow-lg">
              Browse Marketplace
              <ArrowRight className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>
            <button 
              onClick={() => setIsAIModalOpen(true)}
              className="w-full sm:w-auto bg-surface-white/80 backdrop-blur-md border border-border-standard text-text-primary px-4 py-2.5 sm:px-6 sm:py-3 rounded-xl font-button-text text-sm sm:text-base flex justify-center items-center gap-2 hover:bg-surface-soft transition-all shadow-sm bento-hover"
            >
              <PlusSquare className="w-4 h-4 sm:w-5 sm:h-5 text-primary-container" />
              Sell an Item (AI)
            </button>
          </div>
          
          <div className="flex flex-wrap justify-center gap-3 sm:gap-6 pt-2 sm:pt-6 text-[11px] sm:text-sm text-text-secondary font-medium animate-fade-in-up delay-400">
            <div className="flex items-center gap-1 sm:gap-2">
              <ShieldCheck className="text-primary-container w-[14px] h-[14px] sm:w-[18px] sm:h-[18px]" />
              Verified Students
            </div>
            <div className="flex items-center gap-1 sm:gap-2">
              <Lock className="text-primary-container w-[14px] h-[14px] sm:w-[18px] sm:h-[18px]" />
              Secure Transactions
            </div>
            <div className="flex items-center gap-1 sm:gap-2">
              <Building2 className="text-primary-container w-[14px] h-[14px] sm:w-[18px] sm:h-[18px]" />
              Campus Only
            </div>
          </div>
        </div>
      </header>

      {/* Trust Stats Section */}
      <section className="w-full max-w-7xl mx-auto px-2 md:px-8 py-4 md:py-12">
        <div className="bg-surface-white rounded-xl md:rounded-[24px] border border-border-standard p-2 md:p-8 bento-shadow flex flex-nowrap w-full justify-between items-center gap-0.5 md:gap-8 divide-x divide-border-standard overflow-hidden shadow-sm">
          <div className="flex flex-col items-center gap-1 md:flex-row md:gap-4 px-1 md:px-4 animate-fade-in-up delay-100 flex-1 justify-center md:justify-start overflow-hidden">
            <div className="w-5 h-5 md:w-12 md:h-12 rounded-full bg-primary-container/10 flex items-center justify-center text-primary-container shrink-0">
              <Users className="w-2.5 h-2.5 md:w-6 md:h-6" />
            </div>
            <div className="text-center md:text-left max-w-full">
              <div className="font-bold text-[10px] md:font-headline-card md:text-lg text-text-primary leading-tight truncate">1K+</div>
              <div className="text-[7px] md:text-sm text-text-secondary leading-tight truncate">Students</div>
            </div>
          </div>
          
          <div className="flex flex-col items-center gap-1 md:flex-row md:gap-4 px-1 md:px-4 animate-fade-in-up delay-200 flex-1 justify-center md:justify-start overflow-hidden">
            <div className="w-5 h-5 md:w-12 md:h-12 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 shrink-0">
              <LayoutGrid className="w-2.5 h-2.5 md:w-6 md:h-6" />
            </div>
            <div className="text-center md:text-left max-w-full">
              <div className="font-bold text-[10px] md:font-headline-card md:text-lg text-text-primary leading-tight truncate">13</div>
              <div className="text-[7px] md:text-sm text-text-secondary leading-tight truncate">Categories</div>
            </div>
          </div>
          
          <div className="flex flex-col items-center gap-1 md:flex-row md:gap-4 px-1 md:px-4 animate-fade-in-up delay-300 flex-1 justify-center md:justify-start overflow-hidden">
            <div className="w-5 h-5 md:w-12 md:h-12 rounded-full bg-green-100 flex items-center justify-center text-green-600 shrink-0">
              <Zap className="w-2.5 h-2.5 md:w-6 md:h-6" />
            </div>
            <div className="text-center md:text-left max-w-full">
              <div className="font-bold text-[10px] md:font-headline-card md:text-lg text-text-primary leading-tight truncate">24h</div>
              <div className="text-[7px] md:text-sm text-text-secondary leading-tight truncate">Quick Deals</div>
            </div>
          </div>
          
          <div className="flex flex-col items-center gap-1 md:flex-row md:gap-4 px-1 md:px-4 animate-fade-in-up delay-400 flex-1 justify-center md:justify-start overflow-hidden">
            <div className="w-5 h-5 md:w-12 md:h-12 rounded-full bg-purple-100 flex items-center justify-center text-purple-600 shrink-0">
              <Verified className="w-2.5 h-2.5 md:w-6 md:h-6" />
            </div>
            <div className="text-center md:text-left max-w-full">
              <div className="font-bold text-[10px] md:font-headline-card md:text-lg text-text-primary leading-tight truncate">Verified</div>
              <div className="text-[7px] md:text-sm text-text-secondary leading-tight truncate">Students</div>
            </div>
          </div>
        </div>
      </section>

      {/* Categories Filter */}
      <section className="w-full max-w-7xl mx-auto px-4 md:px-8 py-4 md:py-8 overflow-x-auto no-scrollbar" style={{ WebkitOverflowScrolling: 'touch' }}>
        <div className="flex gap-2.5 md:gap-4 min-w-max pb-2">
          <button className="bg-surface-white border border-border-standard px-4 py-2 md:px-5 md:py-2.5 rounded-full flex items-center gap-2 hover:bg-surface-soft shadow-sm hover:-translate-y-0.5 transition-all duration-300">
            <BookOpen className="text-text-secondary w-3.5 h-3.5 md:w-4 md:h-4" />
            <span className="font-medium text-xs md:text-sm">Textbooks</span>
          </button>
          <button className="bg-surface-white border border-border-standard px-4 py-2 md:px-5 md:py-2.5 rounded-full flex items-center gap-2 hover:bg-surface-soft shadow-sm hover:-translate-y-0.5 transition-all duration-300">
            <FileText className="text-text-secondary w-3.5 h-3.5 md:w-4 md:h-4" />
            <span className="font-medium text-xs md:text-sm">Notes & Study Material</span>
          </button>
          <button className="bg-surface-white border border-border-standard px-4 py-2 md:px-5 md:py-2.5 rounded-full flex items-center gap-2 hover:bg-surface-soft shadow-sm hover:-translate-y-0.5 transition-all duration-300">
            <Smartphone className="text-text-secondary w-3.5 h-3.5 md:w-4 md:h-4" />
            <span className="font-medium text-xs md:text-sm">Electronics & Gadgets</span>
          </button>
          <button className="bg-surface-white border border-border-standard px-4 py-2 md:px-5 md:py-2.5 rounded-full flex items-center gap-2 hover:bg-surface-soft shadow-sm hover:-translate-y-0.5 transition-all duration-300">
            <FlaskConical className="text-text-secondary w-3.5 h-3.5 md:w-4 md:h-4" />
            <span className="font-medium text-xs md:text-sm">Lab Equipment</span>
          </button>
          <button className="bg-surface-white border border-border-standard px-4 py-2 md:px-5 md:py-2.5 rounded-full flex items-center gap-2 hover:bg-surface-soft shadow-sm hover:-translate-y-0.5 transition-all duration-300">
            <PenTool className="text-text-secondary w-3.5 h-3.5 md:w-4 md:h-4" />
            <span className="font-medium text-xs md:text-sm">Stationery</span>
          </button>
          <button className="w-8 h-8 md:w-10 md:h-10 bg-surface-white border border-border-standard rounded-full flex items-center justify-center hover:bg-surface-soft shadow-sm hover:-translate-y-0.5 transition-all duration-300 shrink-0">
            <ChevronRight className="text-text-secondary w-4 h-4 md:w-5 md:h-5" />
          </button>
        </div>
      </section>

      {/* Latest Listings */}
      <section className="w-full max-w-7xl mx-auto px-2 md:px-8 py-4 md:py-12">
        <div className="flex justify-between items-center mb-4 md:mb-8 gap-2">
          <h2 className="font-headline-section text-lg md:text-[32px] text-text-primary tracking-tight">Latest Listings</h2>
          <div className="flex gap-1.5 md:gap-4 shrink-0">
            <button className="flex justify-center items-center gap-1 md:gap-2 px-2 py-1 md:px-4 md:py-2 border border-border-standard rounded-md md:rounded-xl bg-surface-white text-[10px] md:text-sm font-medium hover:bg-surface-soft">
              <SlidersHorizontal className="w-3 h-3 md:w-4 md:h-4" />
              Filters
            </button>
            <div className="flex justify-center items-center gap-1 md:gap-2 px-2 py-1 md:px-4 md:py-2 border border-border-standard rounded-md md:rounded-xl bg-surface-white text-[10px] md:text-sm font-medium cursor-pointer">
              Newest
              <ChevronDown className="w-3 h-3 md:w-4 md:h-4" />
            </div>
          </div>
        </div>

        {/* Product Grid - 3 items per row on mobile to fit desktop-like density */}
        <div className="grid grid-cols-3 md:grid-cols-4 gap-2 md:gap-6 mb-8 md:mb-12">
           {/* Mock Product 1 */}
           <div className="bg-surface-white rounded-md md:rounded-2xl border border-border-standard overflow-hidden hover:shadow-md transition-shadow cursor-pointer flex flex-col group">
             <div className="aspect-square bg-surface-container relative w-full overflow-hidden">
               <img src="https://images.unsplash.com/photo-1544947950-fa07a98d237f?q=80&w=300&auto=format&fit=crop" alt="Book" className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-500" />
               <div className="absolute top-1 right-1 md:top-2 md:right-2 bg-success-emerald text-white text-[8px] md:text-[10px] font-bold px-1.5 py-0.5 rounded flex items-center gap-0.5">
                  <Verified className="w-1.5 h-1.5 md:w-2 md:h-2" />
               </div>
             </div>
             <div className="p-1.5 md:p-4 flex flex-col flex-grow">
                <span className="text-[7px] md:text-xs text-primary font-bold mb-0.5 md:mb-1 uppercase tracking-wider">Textbooks</span>
                <h3 className="text-[9px] md:text-sm font-bold text-text-primary line-clamp-2 leading-tight md:leading-snug mb-1 md:mb-2">Calculus Early Transcendentals</h3>
                <div className="mt-auto pt-1 md:pt-2 flex items-center justify-between border-t border-border-standard">
                  <span className="text-[10px] md:text-lg font-bold text-text-primary">$45</span>
                  <span className="text-[6px] md:text-xs text-text-secondary">2h ago</span>
                </div>
             </div>
           </div>
           
           {/* Mock Product 2 */}
           <div className="bg-surface-white rounded-md md:rounded-2xl border border-border-standard overflow-hidden hover:shadow-md transition-shadow cursor-pointer flex flex-col group">
             <div className="aspect-square bg-surface-container relative w-full overflow-hidden">
               <img src="https://images.unsplash.com/photo-1546868871-7041f2a55e12?q=80&w=300&auto=format&fit=crop" alt="Watch" className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-500" />
             </div>
             <div className="p-1.5 md:p-4 flex flex-col flex-grow">
                <span className="text-[7px] md:text-xs text-primary font-bold mb-0.5 md:mb-1 uppercase tracking-wider">Electronics</span>
                <h3 className="text-[9px] md:text-sm font-bold text-text-primary line-clamp-2 leading-tight md:leading-snug mb-1 md:mb-2">Apple Watch Series 7</h3>
                <div className="mt-auto pt-1 md:pt-2 flex items-center justify-between border-t border-border-standard">
                  <span className="text-[10px] md:text-lg font-bold text-text-primary">$120</span>
                  <span className="text-[6px] md:text-xs text-text-secondary">5h ago</span>
                </div>
             </div>
           </div>

           {/* Mock Product 3 */}
           <div className="bg-surface-white rounded-md md:rounded-2xl border border-border-standard overflow-hidden hover:shadow-md transition-shadow cursor-pointer flex flex-col group">
             <div className="aspect-square bg-surface-container relative w-full overflow-hidden bg-white flex items-center justify-center p-2">
               <svg xmlns="http://www.w3.org/2000/svg" className="w-full h-full text-text-secondary opacity-20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
               </svg>
             </div>
             <div className="p-1.5 md:p-4 flex flex-col flex-grow">
                <span className="text-[7px] md:text-xs text-primary font-bold mb-0.5 md:mb-1 uppercase tracking-wider">Notes</span>
                <h3 className="text-[9px] md:text-sm font-bold text-text-primary line-clamp-2 leading-tight md:leading-snug mb-1 md:mb-2">Organic Chem Midterm Notes</h3>
                <div className="mt-auto pt-1 md:pt-2 flex items-center justify-between border-t border-border-standard">
                  <span className="text-[10px] md:text-lg font-bold text-text-primary">$10</span>
                  <span className="text-[6px] md:text-xs text-text-secondary">1d ago</span>
                </div>
             </div>
           </div>

           {/* Mock Product 4 */}
           <div className="bg-surface-white rounded-md md:rounded-2xl border border-border-standard overflow-hidden hover:shadow-md transition-shadow cursor-pointer flex flex-col group hidden md:flex">
             <div className="aspect-square bg-surface-container relative w-full overflow-hidden">
               <img src="https://images.unsplash.com/photo-1555664424-778a1e5e1b48?q=80&w=300&auto=format&fit=crop" alt="iPad" className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-500" />
             </div>
             <div className="p-1.5 md:p-4 flex flex-col flex-grow">
                <span className="text-[7px] md:text-xs text-primary font-bold mb-0.5 md:mb-1 uppercase tracking-wider">Electronics</span>
                <h3 className="text-[9px] md:text-sm font-bold text-text-primary line-clamp-2 leading-tight md:leading-snug mb-1 md:mb-2">iPad Pro 11-inch (2021)</h3>
                <div className="mt-auto pt-1 md:pt-2 flex items-center justify-between border-t border-border-standard">
                  <span className="text-[10px] md:text-lg font-bold text-text-primary">$450</span>
                  <span className="text-[6px] md:text-xs text-text-secondary">1d ago</span>
                </div>
             </div>
           </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="w-full py-10 md:py-16 px-4 md:px-8 mt-auto bg-surface-white border-t border-border-standard relative z-10">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8 md:gap-12 font-body-base text-body-base">
          <div className="space-y-3 md:space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-5 h-5 md:w-6 md:h-6 bg-primary-container rounded flex items-center justify-center text-white font-bold text-[10px] md:text-xs">U</div>
              <span className="font-display-hero-mobile text-lg md:text-xl font-bold tracking-tight text-text-primary">UNIMART</span>
            </div>
            <p className="text-text-secondary text-xs md:text-sm">The premier student-only marketplace. Buy and sell textbooks, electronics, and more with verified fellow students on campus.</p>
            <div className="flex gap-4 pt-1 md:pt-2">
              <a className="w-7 h-7 md:w-8 md:h-8 rounded-full bg-surface-container flex items-center justify-center text-text-secondary hover:bg-primary-container hover:text-white transition-colors" href="#">
                <Send className="w-3.5 h-3.5 md:w-4 md:h-4" />
              </a>
              <a className="w-7 h-7 md:w-8 md:h-8 rounded-full bg-surface-container flex items-center justify-center text-text-secondary hover:bg-primary-container hover:text-white transition-colors" href="#">
                <Mail className="w-3.5 h-3.5 md:w-4 md:h-4" />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="font-bold text-text-primary mb-3 md:mb-4 tracking-wide text-xs md:text-sm font-label-caps uppercase">CATEGORIES</h4>
            <ul className="space-y-2 md:space-y-3 text-xs md:text-sm text-text-secondary">
              <li><a className="hover:text-primary transition-colors flex items-center gap-2" href="#"><BookOpen className="w-3.5 h-3.5 md:w-4 md:h-4" /> Textbooks</a></li>
              <li><a className="hover:text-primary transition-colors flex items-center gap-2" href="#"><FileText className="w-3.5 h-3.5 md:w-4 md:h-4" /> Notes & Study Material</a></li>
              <li><a className="hover:text-primary transition-colors flex items-center gap-2" href="#"><Smartphone className="w-3.5 h-3.5 md:w-4 md:h-4" /> Electronics & Gadgets</a></li>
              <li><a className="hover:text-primary transition-colors flex items-center gap-2" href="#"><FlaskConical className="w-3.5 h-3.5 md:w-4 md:h-4" /> Lab Coats & Equipment</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-bold text-text-primary mb-3 md:mb-4 tracking-wide text-xs md:text-sm font-label-caps uppercase">QUICK LINKS</h4>
            <ul className="space-y-2 md:space-y-3 text-xs md:text-sm text-text-secondary">
              <li><a className="hover:text-primary transition-colors" href="#">Sell a Product</a></li>
              <li><a className="hover:text-primary transition-colors" href="#">My Orders</a></li>
              <li><a className="hover:text-primary transition-colors" href="#">Dashboard</a></li>
              <li><a className="hover:text-primary transition-colors" href="#">Help Center</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-bold text-text-primary mb-2 md:mb-4 tracking-wide text-xs md:text-sm font-label-caps uppercase">STAY UPDATED</h4>
            <p className="text-text-secondary text-xs md:text-sm mb-3 md:mb-4">Get notified about new listings and campus deals.</p>
            <div className="flex gap-2">
              <input className="flex-1 px-3 py-2 md:px-4 md:py-2 rounded-xl bg-surface border border-border-standard text-xs md:text-sm focus:outline-none focus:border-primary-container shadow-inner" placeholder="Enter your email" type="email"/>
              <button className="bg-primary-container text-white px-3 py-2 md:px-4 md:py-2 rounded-xl text-xs md:text-sm font-medium hover:bg-primary transition-colors shadow-sm">Join</button>
            </div>
          </div>
          
          <div className="col-span-1 md:col-span-4 flex flex-col md:flex-row justify-between items-center pt-6 md:pt-8 border-t border-border-standard mt-6 md:mt-8 text-xs md:text-sm text-text-secondary">
            <div>© 2026 UNIMART. All rights reserved.</div>
            <div className="flex items-center gap-1 mt-3 md:mt-0">
              Made with <Heart className="w-3.5 h-3.5 md:w-4 md:h-4 text-primary-container fill-primary-container/20" /> for students everywhere
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

