import React, { useState, useRef } from 'react';
import { Camera, Upload, X, Loader2, Sparkles, AlertCircle } from 'lucide-react';

interface AIAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface AnalysisResult {
  title: string;
  category: string;
  priceEstimate: string;
  description: string;
}

export default function AIAssistantModal({ isOpen, onClose }: AIAssistantModalProps) {
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageBase64, setImageBase64] = useState<string | null>(null);
  const [mimeType, setMimeType] = useState<string | null>(null);
  
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<AnalysisResult | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setError('Please select a valid image file.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      setImagePreview(dataUrl);
      
      // Extract base64 without the prefix
      const base64Data = dataUrl.split(',')[1];
      setImageBase64(base64Data);
      setMimeType(file.type);
      
      setError(null);
      setResult(null);
    };
    reader.readAsDataURL(file);
  };

  const handleAnalyze = async () => {
    if (!imageBase64 || !mimeType) return;
    
    setIsAnalyzing(true);
    setError(null);
    setResult(null);

    try {
      const response = await fetch('/api/analyze-item', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          imageParams: {
            base64: imageBase64,
            mimeType: mimeType,
          }
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to analyze image');
      }

      const data = await response.json();
      setResult(data);
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred during analysis.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleReset = () => {
    setImagePreview(null);
    setImageBase64(null);
    setMimeType(null);
    setResult(null);
    setError(null);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-inverse-surface/40 backdrop-blur-sm p-4 animate-fade-in-up">
      <div className="bg-surface-white w-full max-w-2xl rounded-3xl shadow-xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-border-standard">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-primary-container/10 flex items-center justify-center text-primary-container">
               <Sparkles className="w-5 h-5" />
            </div>
            <h2 className="font-headline-card text-headline-card text-text-primary">AI Item Analyzer</h2>
          </div>
          <button 
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-surface-container transition-colors text-text-secondary"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto flex-1">
          <p className="text-text-secondary mb-6">
            Upload a photo of the item you want to sell. Our AI will automatically categorize it, write an engaging description, and suggest a fair price.
          </p>

          {!imagePreview ? (
            <div 
              className="border-2 border-dashed border-border-standard rounded-2xl p-12 flex flex-col items-center justify-center bg-surface-soft hover:bg-surface-container transition-colors cursor-pointer"
              onClick={() => fileInputRef.current?.click()}
            >
              <Camera className="w-12 h-12 text-outline mb-4" />
              <h3 className="font-headline-card text-headline-card text-text-primary mb-2">Upload Item Photo</h3>
              <p className="text-sm text-text-secondary text-center">Click to browse your device.</p>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="relative rounded-2xl overflow-hidden bg-surface-container h-64 flex items-center justify-center">
                <img src={imagePreview} alt="Item preview" className="max-w-full max-h-full object-contain" />
                <button 
                  onClick={handleReset}
                  className="absolute top-4 right-4 bg-surface-white/80 backdrop-blur-md p-2 rounded-full shadow-sm hover:bg-surface-white transition-colors"
                >
                  <X className="w-4 h-4 text-text-primary" />
                </button>
              </div>

              {error && (
                <div className="bg-error-container text-on-error-container p-4 rounded-xl flex items-start gap-3 text-sm">
                  <AlertCircle className="w-5 h-5 shrink-0" />
                  <p>{error}</p>
                </div>
              )}

              {!result ? (
                <div className="flex justify-end">
                  <button
                    onClick={handleAnalyze}
                    disabled={isAnalyzing}
                    className="bg-primary-container text-white px-6 py-3 rounded-xl font-button-text flex items-center gap-2 hover:bg-primary transition-all disabled:opacity-70 disabled:cursor-not-allowed shadow-md"
                  >
                    {isAnalyzing ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        Analyzing...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-5 h-5" />
                        Analyze Image
                      </>
                    )}
                  </button>
                </div>
              ) : (
                <div className="bg-surface-soft border border-border-standard rounded-2xl p-6 space-y-4 animate-fade-in-up">
                  <h3 className="font-headline-card text-headline-card text-text-primary border-b border-border-standard pb-2">AI Suggestions</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-label-caps text-text-secondary mb-1">TITLE</label>
                      <div className="font-medium text-text-primary bg-surface-white px-3 py-2 border border-border-standard rounded-lg">
                        {result.title}
                      </div>
                    </div>
                    <div>
                      <label className="block text-xs font-label-caps text-text-secondary mb-1">CATEGORY</label>
                      <div className="font-medium text-text-primary bg-surface-white px-3 py-2 border border-border-standard rounded-lg">
                        {result.category}
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-label-caps text-text-secondary mb-1">SUGGESTED PRICE</label>
                    <div className="font-medium text-success-emerald bg-success-emerald/10 px-3 py-2 border border-success-emerald/20 rounded-lg inline-block">
                      {result.priceEstimate}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-label-caps text-text-secondary mb-1">DESCRIPTION</label>
                    <div className="text-sm text-text-secondary bg-surface-white px-3 py-2 border border-border-standard rounded-lg leading-relaxed">
                      {result.description}
                    </div>
                  </div>

                  <div className="pt-4 flex justify-end gap-3 border-t border-border-standard mt-4">
                    <button 
                      onClick={onClose}
                      className="px-6 py-2 border border-border-standard rounded-xl text-text-primary font-button-text hover:bg-surface-container transition-colors"
                    >
                      Cancel
                    </button>
                    <button 
                      onClick={onClose}
                      className="bg-primary-container text-white px-6 py-2 rounded-xl font-button-text hover:bg-primary transition-colors shadow-sm"
                    >
                      Use These Details
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handleFileChange}
            accept="image/*" 
            className="hidden" 
          />
        </div>
      </div>
    </div>
  );
}
